/*
-- Query: SELECT * FROM gogosing.users_like_genre limit 0, 60000
-- Date: 2023-10-06 10:54
*/
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (17,4,36);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (18,5,36);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (19,6,36);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (20,1,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (21,3,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (22,1,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (23,3,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (24,1,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (25,3,48);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (89,4,52);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (90,1,52);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (91,2,52);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (95,8,37);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (96,5,37);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (97,1,45);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (98,3,45);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (105,1,45);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (106,3,45);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (118,5,38);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (119,2,58);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (120,3,58);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (121,1,58);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (137,3,44);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (138,10,59);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (139,2,59);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (140,1,59);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (141,5,60);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (143,3,61);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (144,3,62);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (145,3,63);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (146,2,51);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (147,1,51);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (148,3,51);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (154,3,65);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (155,3,40);
INSERT INTO `` (`users_like_genre_id`,`genre_id`,`user_id`) VALUES (158,3,66);
