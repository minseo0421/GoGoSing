/*
-- Query: SELECT * FROM gogosing.genre limit 0, 60000
-- Date: 2023-10-06 10:47
*/
INSERT INTO `` (`genre_id`,`type`) VALUES (1,'댄스');
INSERT INTO `` (`genre_id`,`type`) VALUES (2,'발라드');
INSERT INTO `` (`genre_id`,`type`) VALUES (3,'랩/힙합');
INSERT INTO `` (`genre_id`,`type`) VALUES (4,'R&B/Soul');
INSERT INTO `` (`genre_id`,`type`) VALUES (5,'인디음악');
INSERT INTO `` (`genre_id`,`type`) VALUES (6,'록/메탈');
INSERT INTO `` (`genre_id`,`type`) VALUES (7,'트로트');
INSERT INTO `` (`genre_id`,`type`) VALUES (8,'포크/블루스');
INSERT INTO `` (`genre_id`,`type`) VALUES (9,'POP');
INSERT INTO `` (`genre_id`,`type`) VALUES (10,'OST');
INSERT INTO `` (`genre_id`,`type`) VALUES (11,'동요');
INSERT INTO `` (`genre_id`,`type`) VALUES (12,'재즈');
INSERT INTO `` (`genre_id`,`type`) VALUES (13,'J-POP');
INSERT INTO `` (`genre_id`,`type`) VALUES (14,'CCM');
INSERT INTO `` (`genre_id`,`type`) VALUES (15,'민요');
